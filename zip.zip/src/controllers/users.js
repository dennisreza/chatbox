const User = require("../Models/users");

exports.createUser = (req, res, next) => {

  const {name, email} = req.body
  //untuk variable baru
  const CreateUser = new User({
    name: name,
    email: email,
  });
  console.log(name, email)
  
  //mengecek proses penyimpanan ke database
  CreateUser.save()
    .then((result) => {
      res.status(201).json({
        message: "Create User Success",
        data: result,
      });
    })
    .catch((err) => console.log("err: ", err));
};
