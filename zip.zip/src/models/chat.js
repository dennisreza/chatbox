const mongoose = require("mongoose");
const roomChatSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  room: {
    type: String,
    required: true
  } 
});

const RoomChat = mongoose.model("room-chat", roomChatSchema);
module.exports = RoomChat;
